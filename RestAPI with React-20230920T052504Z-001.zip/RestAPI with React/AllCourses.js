import axios from "axios";
import { useEffect, useState } from "react";

const AllCourses = () =>{

    const[courses,setCourses] =  useState([])

    useEffect(()=>{
        axios.get("http://localhost:8080/courses/").then(
            response => setCourses(response.data)
        )
    })
    return(
        <div>
            <h3>These are the Available Courses</h3>
            <table className="table table-bordered border-danger">
                <thead className="table-danger text-center">
                    <tr>
                        <th>Course Name</th>
                        <th>Course Duration</th>
                        <th>Course Fee</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        courses.map(i =><tr key={i.courseId}>
                            <td>{i.courseName}</td>
                            <td>{i.courseDuration}</td>
                            <td>{i.courseFee}</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}

export default AllCourses;