import axios from "axios";
import { useState } from "react";

const AddCourse = () =>{

    const[course,setCourse] = useState({
        courseName : "",
        courseDuration : 0,
        courseFee : 0
    })
  
    const{courseName,courseDuration,courseFee} = course;
    const newCourse = (e) =>{
       axios.post("http://localhost:8080/courses/addCourse",course)
    } 

    const changedData = (e)=>{
        setCourse({...course, [e.target.name] : e.target.value})
    }

    return(
        <div>
        <h3>Add New Course</h3>
           <form onSubmit={(e)=>newCourse(e)}>
              <input type="text" placeholder="Course Name" name="courseName" value={courseName} onChange={(e) => changedData(e)}/><br/>
              <input type="number" placeholder="Course Duration" name="courseDuration" value={courseDuration} onChange={(e) => changedData(e)}/><br/>
              <input type="number" placeholder="Course Fee" name="courseFee" value={courseFee} onChange={(e) => changedData(e)}/><br/>
              <button type="submit">Add Course</button>
           </form>
        </div>
    );
}

export default AddCourse;